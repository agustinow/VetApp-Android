package com.odella.vetapp.controller

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.odella.vetapp.R

class VetActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vet)

    }

}
